package com.glasscc

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Req(val title: String, val ok: Boolean, val action: () -> Unit)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    private val wifiPerm =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Glass.init(this)
        setContent { Setup(tick) }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }

    private fun wifiPermOk(): Boolean {
        val loc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val nearby = Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
        return loc || nearby
    }

    @Composable
    private fun Setup(@Suppress("UNUSED_PARAMETER") tick: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val overlayOk = Settings.canDrawOverlays(this)
        val reqs = listOf(
            Req("Display over other apps (zaroori)", overlayOk) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            },
            Req("Modify system settings (brightness, rotation)", Settings.System.canWrite(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            },
            Req("Do Not Disturb access (Focus)", nm.isNotificationPolicyAccessGranted) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            },
            Req("Wi-Fi list (Location / Nearby devices)", wifiPermOk()) {
                val perms = if (Build.VERSION.SDK_INT >= 33) {
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.NEARBY_WIFI_DEVICES)
                } else {
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                }
                wifiPerm.launch(perms)
            },
            Req("Accessibility (power menu, optional)", PowerService.instance != null) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            Req("Notifications (service ka notice)", notifOk) {
                if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            },
        )

        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF1B2A6B), Color(0xFF6B2A8F), Color(0xFF111122))))
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Spacer(Modifier.size(36.dp))
            GText("Glass Control Center", 26.sp)
            GText(
                "Pehle neeche ki permissions do, phir Start dabao. Phir screen ke upar-right kone se neeche swipe karo.",
                14.sp,
                Color.White.copy(0.75f),
            )
            reqs.forEach { r ->
                GlassSurface(Modifier.fillMaxWidth().pressScale({ r.action() }), RoundedCornerShape(22.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        GText(r.title, 14.sp, modifier = Modifier.weight(1f))
                        GText(if (r.ok) "OK" else "Allow", 14.sp, if (r.ok) Color(0xFF30D158) else Color(0xFFFF9F0A))
                    }
                }
            }

            GText("Glass clarity", 14.sp, Color.White.copy(0.85f), Modifier.padding(top = 6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GText("Clear", 12.sp, Color.White.copy(0.8f))
                GlassSurface(
                    Modifier
                        .weight(1f)
                        .height(28.dp)
                        .pointerInput(Unit) { detectTapGestures { Glass.set(it.x / size.width) } }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures { ch, _ ->
                                ch.consume()
                                Glass.set(ch.position.x / size.width)
                            }
                        },
                    CircleShape,
                ) {
                    androidx.compose.foundation.layout.Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(Glass.tint.coerceIn(0.05f, 1f))
                            .background(Color.White.copy(0.9f)),
                    )
                }
                GText("Tinted", 12.sp, Color.White.copy(0.8f))
            }

            GlassSurface(
                Modifier.fillMaxWidth().pressScale({
                    if (Settings.canDrawOverlays(this@MainActivity)) {
                        startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                    } else {
                        reqs[0].action()
                    }
                }),
                RoundedCornerShape(22.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.Center) {
                    GText("Start Control Center", 16.sp)
                }
            }
            GlassSurface(
                Modifier.fillMaxWidth().pressScale({
                    stopService(Intent(this@MainActivity, OverlayService::class.java))
                }),
                RoundedCornerShape(22.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.Center) {
                    GText("Stop", 16.sp, Color.White.copy(0.8f))
                }
            }
        }
    }
}
