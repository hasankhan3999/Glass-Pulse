package com.glasscc

import android.content.Context
import androidx.compose.runtime.mutableStateListOf

const val PAGES = 3

enum class TileSize(val w: Int, val h: Int) { S(1, 1), WIDE(2, 1), TALL(1, 2), BIG(2, 2) }

data class TileDef(val id: String, val title: String, val category: String, val allowed: List<TileSize>)

data class Placed(val id: String, val size: TileSize)

data class Pos(val c: Int, val r: Int)

object Tiles {
    private val flex = listOf(TileSize.S, TileSize.WIDE, TileSize.BIG)
    private val tall = listOf(TileSize.TALL)

    val all = listOf(
        TileDef("connectivity", "Connectivity", "Connectivity", listOf(TileSize.BIG)),
        TileDef("wifi", "Wi-Fi", "Connectivity", flex),
        TileDef("cellular", "Mobile Data", "Connectivity", flex),
        TileDef("bluetooth", "Bluetooth", "Connectivity", flex),
        TileDef("airplane", "Airplane Mode", "Connectivity", flex),
        TileDef("hotspot", "Hotspot", "Connectivity", flex),
        TileDef("vpn", "VPN", "Connectivity", flex),
        TileDef("nearby", "Nearby Share", "Connectivity", flex),
        TileDef("brightness", "Brightness", "Display", tall),
        TileDef("volume", "Volume", "Display", tall),
        TileDef("darkmode", "Dark Mode", "Display", flex),
        TileDef("rotation", "Orientation Lock", "Display", flex),
        TileDef("lowpower", "Low Power Mode", "Display", flex),
        TileDef("nowplaying", "Now Playing", "Media", listOf(TileSize.BIG, TileSize.WIDE)),
        TileDef("cast", "Screen Mirroring", "Media", flex),
        TileDef("focus", "Focus", "Utilities", listOf(TileSize.WIDE, TileSize.S, TileSize.BIG)),
        TileDef("silent", "Silent Mode", "Utilities", flex),
        TileDef("torch", "Flashlight", "Utilities", flex),
        TileDef("timer", "Timer", "Utilities", flex),
        TileDef("alarm", "Alarm", "Utilities", flex),
        TileDef("calculator", "Calculator", "Utilities", flex),
        TileDef("camera", "Camera", "Utilities", flex),
    )

    val byId: Map<String, TileDef> = all.associateBy { it.id }
    val categories = listOf("Connectivity", "Display", "Media", "Utilities")

    val defaultPages: List<List<Placed>> = listOf(
        // Page 1: Favorites / Main
        listOf(
            Placed("connectivity", TileSize.BIG),
            Placed("nowplaying", TileSize.BIG),
            Placed("rotation", TileSize.S),
            Placed("silent", TileSize.S),
            Placed("brightness", TileSize.TALL),
            Placed("volume", TileSize.TALL),
            Placed("focus", TileSize.WIDE),
            Placed("torch", TileSize.S),
            Placed("timer", TileSize.S),
            Placed("calculator", TileSize.S),
            Placed("camera", TileSize.S),
        ),
        // Page 2: Media
        listOf(
            Placed("nowplaying", TileSize.BIG),
            Placed("volume", TileSize.TALL),
            Placed("brightness", TileSize.TALL),
            Placed("cast", TileSize.WIDE),
            Placed("silent", TileSize.S),
            Placed("alarm", TileSize.S),
        ),
        // Page 3: Connectivity / Smart
        listOf(
            Placed("wifi", TileSize.WIDE),
            Placed("bluetooth", TileSize.WIDE),
            Placed("cellular", TileSize.WIDE),
            Placed("hotspot", TileSize.WIDE),
            Placed("airplane", TileSize.S),
            Placed("vpn", TileSize.S),
            Placed("nearby", TileSize.S),
            Placed("darkmode", TileSize.S),
        ),
    )
}

/** 4 column grid mein tiles ko pehli khali jagah par rakhta hai. Returns (positions, rows). */
fun pack(sizes: List<TileSize>): Pair<List<Pos>, Int> {
    val occ = ArrayList<BooleanArray>()
    val pos = ArrayList<Pos>()
    var rows = 0
    for (s in sizes) {
        var r = 0
        var done = false
        while (!done) {
            while (occ.size < r + s.h) occ.add(BooleanArray(4))
            for (c in 0..(4 - s.w)) {
                var free = true
                for (dr in 0 until s.h) for (dc in 0 until s.w) if (occ[r + dr][c + dc]) free = false
                if (free) {
                    for (dr in 0 until s.h) for (dc in 0 until s.w) occ[r + dr][c + dc] = true
                    pos.add(Pos(c, r))
                    rows = maxOf(rows, r + s.h)
                    done = true
                    break
                }
            }
            if (!done) r++
        }
    }
    return pos to rows
}

class LayoutStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cc_layout", Context.MODE_PRIVATE)
    val pages = List(PAGES) { mutableStateListOf<Placed>() }

    init {
        val raw = sp.getString("pages3", null)
        if (raw == null) {
            loadDefaults()
        } else {
            raw.split("|").forEachIndexed { pi, pageRaw ->
                if (pi < PAGES && pageRaw.isNotEmpty()) {
                    pageRaw.split(",").forEach { part ->
                        val p = part.split(":")
                        if (p.size == 2 && Tiles.byId.containsKey(p[0])) {
                            runCatching { TileSize.valueOf(p[1]) }.getOrNull()?.let { pages[pi].add(Placed(p[0], it)) }
                        }
                    }
                }
            }
        }
    }

    private fun loadDefaults() {
        pages.forEachIndexed { i, l ->
            l.clear()
            l.addAll(Tiles.defaultPages[i])
        }
    }

    fun save() {
        val s = pages.joinToString("|") { page -> page.joinToString(",") { "${it.id}:${it.size.name}" } }
        sp.edit().putString("pages3", s).apply()
    }

    fun move(page: Int, from: Int, to: Int) {
        val l = pages[page]
        if (from !in l.indices || to !in l.indices || from == to) return
        val x = l.removeAt(from)
        l.add(to, x)
    }

    fun setSize(page: Int, i: Int, size: TileSize) {
        val l = pages[page]
        if (i in l.indices) l[i] = l[i].copy(size = size)
    }

    fun remove(page: Int, i: Int) {
        val l = pages[page]
        if (i in l.indices) {
            l.removeAt(i)
            save()
        }
    }

    fun add(page: Int, id: String) {
        val def = Tiles.byId[id] ?: return
        val l = pages[page]
        if (l.any { it.id == id }) return
        l.add(Placed(id, def.allowed.first()))
        save()
    }

    fun resetDefaults() {
        loadDefaults()
        save()
    }
}
