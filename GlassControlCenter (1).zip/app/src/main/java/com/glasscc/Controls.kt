package com.glasscc

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.ceil
import kotlin.math.roundToInt

data class WifiNet(val ssid: String, val level: Int, val secure: Boolean, val connected: Boolean)

/** Permission ya setting missing ho to glass prompt dikhane ke liye. */
data class Prompt(val message: String, val intent: Intent)

class Controls(private val ctx: Context) {
    private val cm = ctx.getSystemService(CameraManager::class.java)
    private val am = ctx.getSystemService(AudioManager::class.java)
    private val nm = ctx.getSystemService(NotificationManager::class.java)
    private val wifi = ctx.applicationContext.getSystemService(WifiManager::class.java)
    private val pm = ctx.getSystemService(PowerManager::class.java)
    private val cn = ctx.getSystemService(ConnectivityManager::class.java)
    private val bm = ctx.getSystemService(BatteryManager::class.java)

    val on = mutableStateMapOf<String, Boolean>()
    var brightness by mutableFloatStateOf(0.5f)
    var volume by mutableFloatStateOf(0.5f)
    var battery by mutableIntStateOf(0)
    var torchLevel by mutableIntStateOf(0)
    var focusFilter by mutableIntStateOf(NotificationManager.INTERRUPTION_FILTER_ALL)
    var prompt by mutableStateOf<Prompt?>(null)

    /** Panel ko band karne ka callback (panel set karta hai). */
    var onLaunch: () -> Unit = {}

    private var torchId: String? = null
    var torchMax: Int = 1
        private set
    private var askedWrite = false

    private val stateful = setOf(
        "wifi", "bluetooth", "airplane", "cellular", "vpn", "focus", "rotation",
        "silent", "lowpower", "darkmode", "torch",
    )

    init {
        torchId = runCatching {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        }.getOrNull()
        if (Build.VERSION.SDK_INT >= 33) {
            torchMax = runCatching {
                cm.getCameraCharacteristics(torchId!!).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL)
            }.getOrNull() ?: 1
        }
        runCatching {
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) {
                        on["torch"] = enabled
                        if (!enabled) torchLevel = 0 else if (torchLevel == 0) torchLevel = torchMax
                    }
                }
            }, Handler(Looper.getMainLooper()))
        }
    }

    // ---------- state ----------

    @Suppress("DEPRECATION")
    fun refresh() {
        askedWrite = false
        on["wifi"] = runCatching { wifi.isWifiEnabled }.getOrDefault(false)
        on["bluetooth"] = runCatching { BluetoothAdapter.getDefaultAdapter()?.isEnabled == true }.getOrDefault(false)
        on["airplane"] = Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        focusFilter = nm.currentInterruptionFilter
        on["focus"] = focusFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        on["rotation"] = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        on["silent"] = am.ringerMode != AudioManager.RINGER_MODE_NORMAL
        on["lowpower"] = pm.isPowerSaveMode
        on["darkmode"] = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        on["autobright"] = runCatching {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE) ==
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
        }.getOrDefault(false)
        val caps = runCatching { cn.allNetworks.mapNotNull { cn.getNetworkCapabilities(it) } }
            .getOrDefault(emptyList())
        on["cellular"] = caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) }
        on["vpn"] = caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_VPN) }
        brightness = runCatching {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        }.getOrDefault(0.5f)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        volume = am.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
        battery = runCatching { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }.getOrDefault(0)
    }

    fun sub(id: String): String {
        if (id !in stateful) return ""
        if (id == "wifi" && on["wifi"] == true) return currentSsid() ?: "On"
        return if (on[id] == true) "On" else "Off"
    }

    // ---------- launching / prompts ----------

    fun launch(i: Intent, close: Boolean = true) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
        if (close) onLaunch()
    }

    private fun needWrite() {
        prompt = Prompt(
            "Brightness aur rotation ke liye 'Modify system settings' allow karo.",
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")),
        )
    }

    private fun needPolicy() {
        prompt = Prompt(
            "Focus ke liye Do Not Disturb access allow karo.",
            Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS),
        )
    }

    fun needWifiPerm() {
        prompt = Prompt(
            "Wi-Fi list ke liye app kholo aur Location / Nearby devices permission allow karo.",
            Intent(ctx, MainActivity::class.java),
        )
    }

    fun powerMenu() {
        val s = PowerService.instance
        if (s != null) {
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            onLaunch()
        } else {
            prompt = Prompt(
                "Power menu ke liye Accessibility mein 'Glass Control Center' ko on karo.",
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
            )
        }
    }

    // ---------- sliders ----------

    fun setBrightness(v: Float) {
        brightness = v
        if (Settings.System.canWrite(ctx)) {
            runCatching {
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                Settings.System.putInt(
                    ctx.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).roundToInt().coerceIn(1, 255),
                )
            }
        } else if (!askedWrite) {
            askedWrite = true
            needWrite()
        }
    }

    fun toggleAutoBrightness() {
        if (!Settings.System.canWrite(ctx)) {
            needWrite()
            return
        }
        val auto = on["autobright"] == true
        runCatching {
            Settings.System.putInt(
                ctx.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (auto) Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL else Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC,
            )
        }
        on["autobright"] = !auto
    }

    fun setVolume(v: Float) {
        volume = v
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).roundToInt(), 0) }
    }

    // ---------- torch ----------

    /** level 0 = off. torchMax > 1 ho (Android 13+ aur phone support kare) to intensity chalti hai. */
    fun setTorch(level: Int) {
        val id = torchId ?: return
        if (level <= 0) {
            runCatching { cm.setTorchMode(id, false) }
            torchLevel = 0
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && torchMax > 1) {
            runCatching { cm.turnOnTorchWithStrengthLevel(id, level.coerceIn(1, torchMax)) }
        } else {
            runCatching { cm.setTorchMode(id, true) }
        }
        torchLevel = level
    }

    fun torchSteps(): List<Pair<String, Int>> {
        if (torchMax <= 1) return emptyList()
        return listOf(
            "Low" to 1,
            "Medium" to ceil(torchMax / 3f).toInt().coerceAtLeast(1),
            "High" to ceil(torchMax * 2 / 3f).toInt().coerceAtLeast(1),
            "Max" to torchMax,
        )
    }

    // ---------- focus / ringer / media ----------

    fun setFocus(filter: Int) {
        if (!nm.isNotificationPolicyAccessGranted) {
            needPolicy()
            return
        }
        runCatching { nm.setInterruptionFilter(filter) }
        refresh()
    }

    fun setRinger(mode: Int) {
        runCatching { am.ringerMode = mode }
        refresh()
    }

    fun mediaKey(code: Int) {
        runCatching {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
    }

    // ---------- Wi-Fi scan ----------

    fun hasWifiPerm(): Boolean {
        val loc = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val nearby = Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
        return loc || nearby
    }

    @Suppress("DEPRECATION")
    fun currentSsid(): String? {
        if (!hasWifiPerm()) return null
        return runCatching { wifi.connectionInfo?.ssid?.trim('"') }.getOrNull()
            ?.takeIf { it.isNotBlank() && it != "<unknown ssid>" }
    }

    @Suppress("DEPRECATION")
    fun startScan(): Boolean = runCatching { wifi.startScan() }.getOrDefault(false)

    @Suppress("DEPRECATION")
    fun networks(): List<WifiNet> {
        if (!hasWifiPerm()) return emptyList()
        val cur = currentSsid()
        val results = runCatching { wifi.scanResults }.getOrDefault(emptyList())
        return results
            .filter { !it.SSID.isNullOrBlank() }
            .groupBy { it.SSID }
            .map { (ssid, list) ->
                val best = list.maxByOrNull { it.level }!!
                val caps = best.capabilities ?: ""
                val secure = caps.contains("WEP") || caps.contains("PSK") || caps.contains("SAE") || caps.contains("EAP")
                WifiNet(ssid, WifiManager.calculateSignalLevel(best.level, 4), secure, ssid == cur)
            }
            .sortedWith(compareByDescending<WifiNet> { it.connected }.thenByDescending { it.level })
    }

    fun openWifiPanel() {
        launch(
            if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            else Intent(Settings.ACTION_WIFI_SETTINGS),
        )
    }

    // ---------- taps ----------

    fun tap(id: String) {
        when (id) {
            "torch" -> {
                if (on["torch"] == true) setTorch(0) else setTorch(if (torchMax > 1) torchMax else 1)
            }
            "wifi" -> openWifiPanel()
            "cellular" -> launch(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))
            "bluetooth" -> launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "airplane" -> launch(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            "hotspot" -> launch(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            "vpn" -> launch(Intent(Settings.ACTION_VPN_SETTINGS))
            "nearby" -> launch(Intent(Settings.ACTION_NFC_SETTINGS))
            "focus" -> {
                if (focusFilter == NotificationManager.INTERRUPTION_FILTER_ALL) {
                    setFocus(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                } else {
                    setFocus(NotificationManager.INTERRUPTION_FILTER_ALL)
                }
            }
            "rotation" -> {
                if (Settings.System.canWrite(ctx)) {
                    runCatching {
                        Settings.System.putInt(
                            ctx.contentResolver,
                            Settings.System.ACCELEROMETER_ROTATION,
                            if (on["rotation"] == true) 1 else 0,
                        )
                    }
                    refresh()
                } else {
                    needWrite()
                }
            }
            "silent" -> setRinger(
                if (on["silent"] == true) AudioManager.RINGER_MODE_NORMAL else AudioManager.RINGER_MODE_VIBRATE,
            )
            "timer" -> launch(Intent(AlarmClock.ACTION_SHOW_TIMERS))
            "alarm" -> launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            "calculator" -> launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
            "camera" -> launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "lowpower" -> launch(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            "darkmode" -> launch(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            "cast" -> launch(Intent(Settings.ACTION_CAST_SETTINGS))
        }
    }
}
