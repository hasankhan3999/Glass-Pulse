package com.glasscc

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Power menu kholne ke liye (GLOBAL_ACTION_POWER_DIALOG). Sirf yehi kaam karta hai. */
class PowerService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: PowerService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
