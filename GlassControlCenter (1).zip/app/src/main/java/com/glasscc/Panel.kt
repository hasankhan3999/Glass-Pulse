package com.glasscc

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch

private val GAP = 14.dp

@Composable
fun ControlCenterPanel(controls: Controls, store: LayoutStore, onDismiss: () -> Unit) {
    val haptic = rememberHaptics()
    var editing by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var popup by remember { mutableStateOf<String?>(null) }
    var origin by remember { mutableStateOf<Rect?>(null) }
    var shown by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState { PAGES }

    val t by animateFloatAsState(
        if (shown) 1f else 0f,
        spring(dampingRatio = 0.7f, stiffness = 360f),
        label = "enter",
    )
    val dim by animateFloatAsState(
        if (popup != null) 1f else 0f,
        spring(dampingRatio = 0.78f, stiffness = 380f),
        label = "dim",
    )

    val close: () -> Unit = {
        if (shown) {
            shown = false
            scope.launch {
                delay(220)
                onDismiss()
            }
        }
    }
    SideEffect { controls.onLaunch = close }
    LaunchedEffect(Unit) { shown = true }
    LaunchedEffect(pager) {
        snapshotFlow { pager.currentPage }.drop(1).collect { haptic(H.TICK) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { if (editing) editing = false else close() },
                    onLongPress = {
                        if (!editing) {
                            editing = true
                            haptic(H.LONG)
                        }
                    },
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dy -> if (dy < -25f && !editing) close() }
            },
    ) {
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 440.dp)
                .fillMaxWidth()
                .graphicsLayer {
                    transformOrigin = TransformOrigin(1f, 0f)
                    val k = (0.85f + 0.15f * t) * (1f - 0.08f * dim)
                    scaleX = k
                    scaleY = k
                    alpha = t.coerceIn(0f, 1f)
                    translationY = -30f * (1f - t)
                }
                .blur((10f * dim).dp)
                .padding(start = 18.dp, end = 18.dp, top = 48.dp),
        ) {
            TopBar(
                editing = editing,
                battery = controls.battery,
                onPlus = { if (!editing) editing = true else adding = true },
                onDone = { editing = false },
                onPower = { controls.powerMenu() },
            )
            if (editing) ClaritySlider()
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val cellDp = (maxWidth - GAP * 3) / 4
                VerticalPager(
                    state = pager,
                    modifier = Modifier.fillMaxWidth().height(cellDp * 6 + GAP * 5),
                    userScrollEnabled = !dragging,
                ) { page ->
                    PageGrid(
                        page = page,
                        store = store,
                        controls = controls,
                        cellDp = cellDp,
                        editing = editing,
                        onLongTile = { id, r ->
                            origin = r
                            popup = id
                        },
                        onDragging = { dragging = it },
                    )
                }
            }
        }

        PageDots(
            count = PAGES,
            current = pager.currentPage,
            modifier = Modifier.align(Alignment.CenterEnd),
        ) { idx -> scope.launch { pager.animateScrollToPage(idx) } }

        popup?.let { id ->
            PopupHost(
                id = id,
                origin = origin,
                c = controls,
                onSwitch = { popup = it },
                onClose = { popup = null },
            )
        }
        if (adding) AddSheet(pager.currentPage, store) { adding = false }
        controls.prompt?.let { pr ->
            PromptCard(
                pr,
                onGo = {
                    controls.prompt = null
                    controls.launch(pr.intent)
                },
                onClose = { controls.prompt = null },
            )
        }
    }
}

// ---------- top bar ----------

@Composable
private fun RoundGlassButton(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    GlassSurface(Modifier.size(42.dp).pressScale(onClick), CircleShape) {
        GIcon(icon, Color.White, 22.dp, Modifier.align(Alignment.Center))
    }
}

@Composable
private fun TopBar(
    editing: Boolean,
    battery: Int,
    onPlus: () -> Unit,
    onDone: () -> Unit,
    onPower: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RoundGlassButton(Icons.Rounded.Add, onPlus)
        if (editing) {
            GlassSurface(Modifier.pressScale(onDone), RoundedCornerShape(22.dp)) {
                GText("Done", 15.sp, Color.White, Modifier.padding(horizontal = 20.dp, vertical = 11.dp))
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GText("$battery%", 14.sp, Color.White)
                RoundGlassButton(Icons.Rounded.PowerSettingsNew, onPower)
            }
        }
    }
}

@Composable
private fun ClaritySlider() {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        GText("Clear", 12.sp, Color.White.copy(0.8f))
        GlassSurface(
            Modifier
                .weight(1f)
                .height(26.dp)
                .pointerInput(Unit) { detectTapGestures { Glass.set(it.x / size.width) } }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { ch, _ ->
                        ch.consume()
                        Glass.set(ch.position.x / size.width)
                    }
                },
            CircleShape,
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(Glass.tint.coerceIn(0.05f, 1f))
                    .background(Color.White.copy(0.9f)),
            )
        }
        GText("Tinted", 12.sp, Color.White.copy(0.8f))
    }
}

@Composable
private fun PageDots(count: Int, current: Int, modifier: Modifier, onSelect: (Int) -> Unit) {
    Column(
        modifier
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ ->
                    onSelect((change.position.y / (size.height / count.toFloat())).toInt().coerceIn(0, count - 1))
                }
            }
            .padding(horizontal = 8.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        repeat(count) { i ->
            Box(
                Modifier
                    .size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(if (i == current) 0.95f else 0.35f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        onSelect(i)
                    },
            )
        }
    }
}

// ---------- page grid: animated reflow, drag reorder, resize ----------

@Composable
private fun PageGrid(
    page: Int,
    store: LayoutStore,
    controls: Controls,
    cellDp: Dp,
    editing: Boolean,
    onLongTile: (String, Rect) -> Unit,
    onDragging: (Boolean) -> Unit,
) {
    val items = store.pages[page]
    val haptic = rememberHaptics()
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val cell = with(density) { cellDp.toPx() }
    val gap = with(density) { GAP.toPx() }
    val step = cell + gap

    var dragId by remember { mutableStateOf<String?>(null) }
    var releasing by remember { mutableStateOf(false) }
    var fp by remember { mutableStateOf(Offset.Zero) }
    var grab by remember { mutableStateOf(Offset.Zero) }
    var relFrom by remember { mutableStateOf(Offset.Zero) }
    val rel = remember { Animatable(0f) }
    var stretchId by remember { mutableStateOf<String?>(null) }
    var stX by remember { mutableFloatStateOf(1f) }
    var stY by remember { mutableFloatStateOf(1f) }
    val sxA by animateFloatAsState(stX, spring(dampingRatio = 0.5f, stiffness = 300f), label = "stx")
    val syA by animateFloatAsState(stY, spring(dampingRatio = 0.5f, stiffness = 300f), label = "sty")

    fun endDrag() {
        if (dragId == null || releasing) return
        stX = 1f
        stY = 1f
        scope.launch {
            relFrom = fp - grab
            releasing = true
            rel.snapTo(0f)
            rel.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 300f))
            releasing = false
            dragId = null
            stretchId = null
            store.save()
            haptic(H.TICK)
            onDragging(false)
        }
    }

    val (positions, rows) = pack(items.map { it.size })
    Box(
        Modifier
            .fillMaxWidth()
            .height(cellDp * rows.coerceAtLeast(1) + GAP * (rows - 1).coerceAtLeast(0)),
    ) {
        items.forEachIndexed { i, p ->
            key(p.id) {
                val pos = positions.getOrNull(i) ?: Pos(0, 0)
                val target = IntOffset((pos.c * step).roundToInt(), (pos.r * step).roundToInt())
                val animated by animateIntOffsetAsState(
                    target,
                    spring(dampingRatio = 0.8f, stiffness = 380f),
                    label = "pos",
                )
                val wDp by animateDpAsState(
                    cellDp * p.size.w + GAP * (p.size.w - 1),
                    spring(dampingRatio = 0.8f, stiffness = 380f),
                    label = "w",
                )
                val hDp by animateDpAsState(
                    cellDp * p.size.h + GAP * (p.size.h - 1),
                    spring(dampingRatio = 0.8f, stiffness = 380f),
                    label = "h",
                )
                val isDrag = dragId == p.id
                val isStretch = stretchId == p.id
                val jiggle = rememberInfiniteTransition(label = "jiggle")
                val rot by jiggle.animateFloat(
                    -1.5f,
                    1.5f,
                    infiniteRepeatable(
                        tween(120 + (p.id.hashCode() and 31) * 4, easing = LinearEasing),
                        RepeatMode.Reverse,
                    ),
                    label = "rot",
                )
                var bounds by remember { mutableStateOf(Rect.Zero) }

                val dragMod = if (editing) {
                    Modifier.pointerInput(p.id) {
                        detectDragGestures(
                            onDragStart = { o ->
                                if (dragId == null) {
                                    dragId = p.id
                                    releasing = false
                                    grab = o
                                    fp = Offset(animated.x.toFloat(), animated.y.toFloat()) + o
                                    stretchId = p.id
                                    stX = 1f
                                    stY = 1f
                                    haptic(H.LONG)
                                    onDragging(true)
                                }
                            },
                            onDragEnd = { endDrag() },
                            onDragCancel = { endDrag() },
                        ) { change, amt ->
                            if (dragId == p.id && !releasing) {
                                change.consume()
                                fp += amt
                                val idx = items.indexOfFirst { it.id == p.id }
                                if (idx >= 0) {
                                    val sz = items[idx].size
                                    val center = (fp - grab) + Offset(
                                        (sz.w * cell + (sz.w - 1) * gap) / 2f,
                                        (sz.h * cell + (sz.h - 1) * gap) / 2f,
                                    )
                                    val (ps, _) = pack(items.map { it.size })
                                    for (j in items.indices) {
                                        if (j == idx) continue
                                        val q = ps[j]
                                        val s2 = items[j].size
                                        val x0 = q.c * step
                                        val y0 = q.r * step
                                        val x1 = x0 + s2.w * cell + (s2.w - 1) * gap
                                        val y1 = y0 + s2.h * cell + (s2.h - 1) * gap
                                        if (center.x in x0..x1 && center.y in y0..y1) {
                                            store.move(page, idx, j)
                                            haptic(H.TICK)
                                            break
                                        }
                                    }
                                }
                                stX = (1f + (abs(amt.x) - abs(amt.y)) * 0.004f).coerceIn(0.94f, 1.07f)
                                stY = (2f - stX).coerceIn(0.94f, 1.07f)
                            }
                        }
                    }
                } else {
                    Modifier
                }

                Box(
                    Modifier
                        .offset {
                            if (isDrag) {
                                if (releasing) {
                                    val tt = rel.value
                                    IntOffset(
                                        (relFrom.x + (animated.x - relFrom.x) * tt).roundToInt(),
                                        (relFrom.y + (animated.y - relFrom.y) * tt).roundToInt(),
                                    )
                                } else {
                                    IntOffset((fp.x - grab.x).roundToInt(), (fp.y - grab.y).roundToInt())
                                }
                            } else {
                                animated
                            }
                        }
                        .size(wDp, hDp)
                        .zIndex(if (isDrag) 10f else 0f)
                        .graphicsLayer {
                            if (editing && !isDrag) rotationZ = rot
                            if (isDrag || isStretch) {
                                val lift = if (isDrag) 1.04f else 1f
                                scaleX = sxA * lift
                                scaleY = syA * lift
                            }
                        }
                        .onGloballyPositioned { bounds = it.boundsInRoot() }
                        .then(dragMod),
                ) {
                    TileContent(p, controls) { popupId -> onLongTile(popupId, bounds) }
                    if (editing) {
                        // Edit mode mein tile ke andar ke taps band
                        Box(
                            Modifier
                                .fillMaxSize()
                                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
                        )
                        Box(
                            Modifier
                                .align(Alignment.TopStart)
                                .offset(x = (-4).dp, y = (-4).dp)
                                .pressScale({
                                    val idx = items.indexOfFirst { it.id == p.id }
                                    store.remove(page, idx)
                                })
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE5E5EA)),
                            contentAlignment = Alignment.Center,
                        ) { GIcon(Icons.Rounded.Remove, Color(0xFF3A3A3C), 16.dp) }

                        if ((Tiles.byId[p.id]?.allowed?.size ?: 1) > 1) {
                            Box(
                                Modifier
                                    .align(Alignment.BottomEnd)
                                    .offset(x = 4.dp, y = 4.dp)
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE5E5EA))
                                    .pointerInput(p.id) {
                                        var acc = Offset.Zero
                                        var w0 = 1
                                        var h0 = 1
                                        detectDragGestures(
                                            onDragStart = {
                                                acc = Offset.Zero
                                                val s = items.firstOrNull { it.id == p.id }?.size ?: p.size
                                                w0 = s.w
                                                h0 = s.h
                                                stretchId = p.id
                                                haptic(H.LONG)
                                                onDragging(true)
                                            },
                                            onDragEnd = {
                                                stX = 1f
                                                stY = 1f
                                                stretchId = null
                                                store.save()
                                                onDragging(false)
                                            },
                                            onDragCancel = {
                                                stX = 1f
                                                stY = 1f
                                                stretchId = null
                                                store.save()
                                                onDragging(false)
                                            },
                                        ) { change, amt ->
                                            change.consume()
                                            acc += amt
                                            val allowed = Tiles.byId[p.id]?.allowed ?: return@detectDragGestures
                                            val dc = (w0 * cell + (w0 - 1) * gap + acc.x + gap) / step
                                            val dr = (h0 * cell + (h0 - 1) * gap + acc.y + gap) / step
                                            val best = allowed.minByOrNull {
                                                (it.w - dc) * (it.w - dc) + (it.h - dr) * (it.h - dr)
                                            } ?: return@detectDragGestures
                                            val idx = items.indexOfFirst { it.id == p.id }
                                            if (idx >= 0 && items[idx].size != best) {
                                                store.setSize(page, idx, best)
                                                haptic(H.TICK)
                                            }
                                            val maxW = allowed.maxOf { it.w }
                                            val minW = allowed.minOf { it.w }
                                            val maxH = allowed.maxOf { it.h }
                                            val minH = allowed.minOf { it.h }
                                            val ox = max(0f, max(dc - maxW, minW - dc)).coerceAtMost(1.4f)
                                            val oy = max(0f, max(dr - maxH, minH - dr)).coerceAtMost(1.4f)
                                            stX = (1f + 0.05f * ox - 0.03f * oy).coerceIn(0.94f, 1.07f)
                                            stY = (1f + 0.05f * oy - 0.03f * ox).coerceIn(0.94f, 1.07f)
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) { GIcon(Icons.Rounded.OpenInFull, Color(0xFF3A3A3C), 15.dp) }
                        }
                    }
                }
            }
        }
    }
}

// ---------- add sheet (searchable, categorized) ----------

@Composable
private fun BoxScope.AddSheet(page: Int, store: LayoutStore, onClose: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val present = store.pages[page].map { it.id }.toSet()
    val avail = Tiles.all.filter { it.id !in present && (q.isBlank() || it.title.contains(q, ignoreCase = true)) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(0.4f))
            .pointerInput(Unit) { detectTapGestures { onClose() } },
    )
    GlassSurface(
        Modifier
            .align(Alignment.TopCenter)
            .fillMaxWidth()
            .padding(start = 14.dp, end = 14.dp, top = 70.dp)
            .heightIn(max = 460.dp)
            .pointerInput(Unit) { detectTapGestures { } },
        RoundedCornerShape(32.dp),
        extraScrim = 0.2f,
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                GText("Add a Control", 18.sp, Color.White, Modifier.weight(1f))
                Box(Modifier.pressScale(onClose).padding(4.dp)) { GIcon(Icons.Rounded.Close, Color.White, 22.dp) }
            }
            Spacer(Modifier.height(10.dp))
            GlassSurface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp)) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    GIcon(Icons.Rounded.Search, Color.White.copy(0.7f), 20.dp)
                    BasicTextField(
                        value = q,
                        onValueChange = { q = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            Box {
                                if (q.isEmpty()) GText("Search controls", 15.sp, Color.White.copy(0.5f))
                                inner()
                            }
                        },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                if (avail.isEmpty()) GText("Kuch nahi mila", 14.sp, Color.White.copy(0.7f), Modifier.padding(8.dp))
                Tiles.categories.forEach { cat ->
                    val list = avail.filter { it.category == cat }
                    if (list.isNotEmpty()) {
                        GText(cat.uppercase(), 11.sp, Color.White.copy(0.55f), Modifier.padding(top = 12.dp, bottom = 2.dp))
                        list.forEach { d ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .pressScale({ store.add(page, d.id) })
                                    .padding(vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                GIcon(Metas.of(d.id).icon, Color.White, 24.dp)
                                GText(d.title, 15.sp, Color.White, Modifier.weight(1f))
                                GIcon(Icons.Rounded.Add, Color.White, 22.dp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- permission prompt ----------

@Composable
private fun BoxScope.PromptCard(p: Prompt, onGo: () -> Unit, onClose: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(0.35f))
            .pointerInput(Unit) { detectTapGestures { onClose() } },
        contentAlignment = Alignment.Center,
    ) {
        GlassSurface(
            Modifier.padding(32.dp).pointerInput(Unit) { detectTapGestures { } },
            RoundedCornerShape(30.dp),
            extraScrim = 0.25f,
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                GText(p.message, 15.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassSurface(Modifier.pressScale(onGo), RoundedCornerShape(20.dp)) {
                        GText("Settings kholo", 14.sp, Color.White, Modifier.padding(horizontal = 18.dp, vertical = 10.dp))
                    }
                    GlassSurface(Modifier.pressScale(onClose), RoundedCornerShape(20.dp)) {
                        GText("Baad mein", 14.sp, Color.White.copy(0.8f), Modifier.padding(horizontal = 18.dp, vertical = 10.dp))
                    }
                }
            }
        }
    }
}
