package com.glasscc

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

/** ComposeView ko Service ke andar chalane ke liye lifecycle owner. */
class ServiceOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    fun create() {
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var controls: Controls
    private lateinit var store: LayoutStore
    private val owner = ServiceOwner()
    private var trigger: View? = null
    private var panel: ComposeView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        owner.create()
        Glass.init(this)
        wm = getSystemService(WindowManager::class.java)
        controls = Controls(applicationContext)
        store = LayoutStore(applicationContext)
        startAsForeground()
        runCatching { addTrigger() }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cc", "Control Center", NotificationManager.IMPORTANCE_MIN),
        )
        val n = Notification.Builder(this, "cc")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Control Center chal raha hai")
            .setContentText("Screen ke upar-right kone se neeche swipe karo")
            .build()
        ServiceCompat.startForeground(
            this,
            1,
            n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
        )
    }

    private fun dp(x: Int): Float = x * resources.displayMetrics.density

    @SuppressLint("ClickableViewAccessibility")
    private fun addTrigger() {
        val v = View(this)
        var startY = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fired && e.rawY - startY > dp(36)) {
                        fired = true
                        showPanel()
                    }
                }
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            dp(120).toInt(),
            dp(28).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.END }
        wm.addView(v, lp)
        trigger = v
    }

    private fun showPanel() {
        if (panel != null) return
        controls.refresh()
        val v = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent { ControlCenterPanel(controls, store) { hidePanel() } }
            isFocusableInTouchMode = true
            setOnKeyListener { _, code, ev ->
                if (code == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) {
                    controls.onLaunch()
                    true
                } else {
                    false
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_BLUR_BEHIND or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT,
        ).apply {
            dimAmount = 0.28f
            if (Build.VERSION.SDK_INT >= 31) blurBehindRadius = 70
        }
        wm.addView(v, lp)
        panel = v
        v.requestFocus()
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    override fun onDestroy() {
        hidePanel()
        trigger?.let { runCatching { wm.removeView(it) } }
        trigger = null
        owner.destroy()
        super.onDestroy()
    }
}
