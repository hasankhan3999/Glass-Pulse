package com.glasscc

import android.content.Context
import android.content.SharedPreferences
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Glass ki clarity: 0 = Clear (transparent), 1 = Tinted (zyada contrast). */
object Glass {
    var tint by mutableFloatStateOf(0.5f)
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp == null) {
            sp = ctx.applicationContext.getSharedPreferences("cc_glass", Context.MODE_PRIVATE)
            tint = sp?.getFloat("tint", 0.5f) ?: 0.5f
        }
    }

    fun set(v: Float) {
        tint = v.coerceIn(0f, 1f)
        sp?.edit()?.putFloat("tint", tint)?.apply()
    }
}

@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    extraScrim: Float = 0f,
    content: @Composable BoxScope.() -> Unit,
) {
    val t = Glass.tint
    val white = 0.10f + 0.10f * t
    val scrim = (0.06f + 0.40f * t + extraScrim).coerceAtMost(0.85f)
    Box(
        modifier
            .clip(shape)
            .background(Color(0xFF0F0F14).copy(alpha = scrim))
            .background(Brush.verticalGradient(listOf(Color.White.copy(white + 0.08f), Color.White.copy(white))))
            .border(
                1.2.dp,
                Brush.linearGradient(
                    listOf(Color.White.copy(0.70f), Color.White.copy(0.15f), Color.White.copy(0.45f)),
                ),
                shape,
            ),
        content = content,
    )
}

/** Press par chhota (0.93), chhorne par bouncy spring se wapas. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.pressScale(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.93f else 1f,
        spring(dampingRatio = 0.65f, stiffness = 420f),
        label = "press",
    )
    graphicsLayer {
        scaleX = s
        scaleY = s
    }.combinedClickable(
        interactionSource = src,
        indication = null,
        onClick = onClick,
        onLongClick = onLong,
    )
}

@Composable
fun rememberHaptics(): (Int) -> Unit {
    val view = LocalView.current
    return remember(view) { { code: Int -> view.performHapticFeedback(code); Unit } }
}

object H {
    const val TICK = HapticFeedbackConstants.CLOCK_TICK
    const val LONG = HapticFeedbackConstants.LONG_PRESS
}

@Composable
fun GText(
    text: String,
    size: TextUnit = 13.sp,
    color: Color = Color.White,
    modifier: Modifier = Modifier,
) {
    BasicText(text, modifier, style = TextStyle(color = color, fontSize = size, fontWeight = FontWeight.SemiBold))
}

@Composable
fun GIcon(icon: ImageVector, tint: Color = Color.White, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Image(icon, null, modifier.size(size), colorFilter = ColorFilter.tint(tint))
}

@Composable
fun GlassSpinner(size: Dp = 18.dp) {
    val t = rememberInfiniteTransition(label = "spin")
    val a by t.animateFloat(
        0f,
        360f,
        infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "angle",
    )
    Canvas(Modifier.size(size)) {
        drawArc(
            color = Color.White,
            startAngle = a,
            sweepAngle = 100f,
            useCenter = false,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
        )
    }
}

@Composable
fun SignalBars(level: Int, tint: Color = Color.White) {
    Canvas(Modifier.size(22.dp, 16.dp)) {
        val bw = size.width / 7f
        for (i in 0..3) {
            val h = size.height * (i + 1) / 4f
            drawRoundRect(
                color = tint.copy(if (i <= level) 1f else 0.3f),
                topLeft = Offset(i * bw * 1.8f, size.height - h),
                size = androidx.compose.ui.geometry.Size(bw, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(1.5f, 1.5f),
            )
        }
    }
}
