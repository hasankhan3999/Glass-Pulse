package com.glasscc

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.app.NotificationManager
import android.net.wifi.WifiManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Long-tap par tile se nikalne wala centered glass modal (spring morph). */
@Composable
fun PopupHost(id: String, origin: Rect?, c: Controls, onSwitch: (String) -> Unit, onClose: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    val p by animateFloatAsState(
        if (shown) 1f else 0f,
        spring(dampingRatio = 0.78f, stiffness = 380f),
        label = "popup",
    )
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    val scope = rememberCoroutineScope()
    val close: () -> Unit = {
        if (shown) {
            shown = false
            scope.launch {
                delay(240)
                onClose()
            }
        }
    }
    LaunchedEffect(Unit) { shown = true }
    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { rootSize = it }
            .background(Color.Black.copy(alpha = 0.28f * p))
            .pointerInput(Unit) { detectTapGestures { close() } },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .padding(24.dp)
                .widthIn(max = 380.dp)
                .graphicsLayer {
                    val ox = origin?.let { it.center.x - rootSize.width / 2f } ?: 0f
                    val oy = origin?.let { it.center.y - rootSize.height / 2f } ?: 0f
                    val s = 0.35f + 0.65f * p
                    scaleX = s
                    scaleY = s
                    translationX = ox * (1f - p)
                    translationY = oy * (1f - p)
                    alpha = p.coerceIn(0f, 1f)
                }
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            GlassSurface(Modifier.fillMaxWidth(), RoundedCornerShape(32.dp), extraScrim = 0.22f) {
                Box(Modifier.padding(18.dp)) { PopupContent(id, c, onSwitch) }
            }
        }
    }
}

@Composable
private fun PopupContent(id: String, c: Controls, onSwitch: (String) -> Unit) {
    when (id) {
        "wifi" -> WifiPopup(c)
        "connectivity" -> ConnectivityPopup(c, onSwitch)
        "brightness" -> BrightnessPopup(c)
        "torch" -> TorchPopup(c)
        "nowplaying" -> MediaPopup(c)
        "focus" -> FocusPopup(c)
        else -> QuickMenu(id, c)
    }
}

// ---------- shared rows ----------

@Composable
private fun PopupRow(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().pressScale(onClick).padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GIcon(icon, Color.White, 24.dp)
        Spacer(Modifier.width(14.dp))
        GText(label, 15.sp, Color.White, Modifier.weight(1f))
        if (active) GIcon(Icons.Rounded.Check, Color(0xFF30D158), 22.dp)
    }
}

@Composable
private fun PopupTitle(text: String, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        GText(text, 20.sp, Color.White, Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun Pill(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .pressScale(onClick)
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) Color.White else Color.White.copy(0.2f))
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        GText(text, 13.sp, if (active) Color(0xFF111111) else Color.White)
    }
}

// ---------- Wi-Fi popup ----------

@Composable
fun WifiPopup(c: Controls) {
    val ctx = LocalContext.current
    val hasPerm = c.hasWifiPerm()
    var nets by remember { mutableStateOf(c.networks()) }
    var scanning by remember { mutableStateOf(hasPerm) }

    DisposableEffect(Unit) {
        val rec = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                nets = c.networks()
                scanning = false
            }
        }
        ContextCompat.registerReceiver(
            ctx,
            rec,
            IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        if (hasPerm) c.startScan()
        onDispose { runCatching { ctx.unregisterReceiver(rec) } }
    }
    LaunchedEffect(Unit) {
        delay(7000)
        scanning = false
    }

    Column {
        PopupTitle("Wi-Fi") {
            if (scanning) {
                GlassSpinner(18.dp)
                Spacer(Modifier.width(10.dp))
            }
            Pill(if (c.on["wifi"] == true) "On" else "Off", c.on["wifi"] == true) { c.openWifiPanel() }
        }
        if (!hasPerm) {
            GText(
                "Networks dekhne ke liye Location / Nearby devices permission chahiye.",
                13.sp,
                Color.White.copy(0.75f),
                Modifier.padding(vertical = 10.dp),
            )
            Pill("Permission do", true) { c.needWifiPerm() }
        } else if (c.on["wifi"] != true) {
            GText("Wi-Fi band hai. On karne ke liye upar tap karo.", 13.sp, Color.White.copy(0.75f), Modifier.padding(vertical = 10.dp))
        } else if (nets.isEmpty()) {
            GText(
                if (scanning) "Networks dhoond raha hoon..." else "Koi network nahi mila.",
                13.sp,
                Color.White.copy(0.75f),
                Modifier.padding(vertical = 10.dp),
            )
        } else {
            LazyColumn(Modifier.heightIn(max = 300.dp)) {
                items(nets, key = { it.ssid }) { n ->
                    Row(
                        Modifier.fillMaxWidth().pressScale({ c.openWifiPanel() }).padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
                            if (n.connected) GIcon(Icons.Rounded.Check, Color(0xFF0A84FF), 20.dp)
                        }
                        Column(Modifier.weight(1f)) {
                            GText(n.ssid, 15.sp, Color.White)
                            if (n.connected) GText("Connected", 11.sp, Color.White.copy(0.65f))
                        }
                        if (n.secure) {
                            GIcon(Icons.Rounded.Lock, Color.White.copy(0.8f), 16.dp)
                            Spacer(Modifier.width(10.dp))
                        }
                        SignalBars(n.level)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Pill("Wi-Fi Settings", false) { c.launch(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        }
    }
}

// ---------- Connectivity popup ----------

@Composable
private fun ConnItem(id: String, label: String, c: Controls, onClick: () -> Unit, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Orb(id, c, 58.dp, onClick) {}
        Spacer(Modifier.height(6.dp))
        GText(label, 12.sp, Color.White)
        GText(if (c.on[id] == true) "On" else "Off", 11.sp, Color.White.copy(0.6f))
    }
}

@Composable
private fun ConnectivityPopup(c: Controls, onSwitch: (String) -> Unit) {
    Column {
        PopupTitle("Connectivity")
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            ConnItem("airplane", "Airplane", c, { c.tap("airplane") }, Modifier.weight(1f))
            ConnItem("cellular", "Cellular", c, { c.tap("cellular") }, Modifier.weight(1f))
            ConnItem("wifi", "Wi-Fi", c, { onSwitch("wifi") }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            ConnItem("bluetooth", "Bluetooth", c, { c.tap("bluetooth") }, Modifier.weight(1f))
            ConnItem("hotspot", "Hotspot", c, { c.tap("hotspot") }, Modifier.weight(1f))
            ConnItem("vpn", "VPN", c, { c.tap("vpn") }, Modifier.weight(1f))
        }
    }
}

// ---------- Brightness popup ----------

@Composable
private fun BrightnessPopup(c: Controls) {
    Column {
        PopupTitle("Brightness")
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Box(Modifier.width(90.dp).height(230.dp)) {
                SliderTile(c.brightness, Icons.Rounded.WbSunny, {}) { c.setBrightness(it) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                PopupRow(Metas.of("darkmode").icon, "Dark Mode", c.on["darkmode"] == true) { c.tap("darkmode") }
                PopupRow(Metas.of("autobright").icon, "Auto-Brightness", c.on["autobright"] == true) {
                    c.toggleAutoBrightness()
                }
                PopupRow(Icons.Rounded.Settings, "Eye Comfort", false) { c.launch(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            }
        }
    }
}

// ---------- Flashlight popup ----------

@Composable
private fun TorchPopup(c: Controls) {
    val steps = c.torchSteps()
    Column {
        PopupTitle("Flashlight")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Off", c.on["torch"] != true) { c.setTorch(0) }
            if (steps.isEmpty()) {
                Pill("On", c.on["torch"] == true) { c.setTorch(1) }
            } else {
                steps.forEach { (label, lvl) ->
                    Pill(label, c.on["torch"] == true && c.torchLevel == lvl) { c.setTorch(lvl) }
                }
            }
        }
        if (steps.isEmpty()) {
            GText(
                "Is phone ka flashlight sirf on/off support karta hai (intensity levels nahi).",
                12.sp,
                Color.White.copy(0.65f),
                Modifier.padding(top = 12.dp),
            )
        }
    }
}

// ---------- Media popup ----------

@Composable
private fun MediaPopup(c: Controls) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        GlassSurface(Modifier.size(150.dp), RoundedCornerShape(24.dp)) {
            GIcon(Icons.Rounded.MusicNote, Color.White.copy(0.7f), 56.dp, Modifier.align(Alignment.Center))
        }
        Spacer(Modifier.height(12.dp))
        GText("Not Playing", 18.sp)
        GText("Track ki tafseel agle hisse mein", 12.sp, Color.White.copy(0.6f))
        Spacer(Modifier.height(12.dp))
        GlassSurface(Modifier.fillMaxWidth().height(6.dp), CircleShape) {}
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.pressScale({ c.mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }).padding(8.dp)) {
                GIcon(Icons.Rounded.SkipPrevious, Color.White, 34.dp)
            }
            Box(Modifier.pressScale({ c.mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }).padding(8.dp)) {
                GIcon(Icons.Rounded.PlayArrow, Color.White, 44.dp)
            }
            Box(Modifier.pressScale({ c.mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT) }).padding(8.dp)) {
                GIcon(Icons.Rounded.SkipNext, Color.White, 34.dp)
            }
        }
        Spacer(Modifier.height(6.dp))
        Pill("Output", false) { c.launch(Intent(Settings.Panel.ACTION_VOLUME)) }
    }
}

// ---------- Focus popup ----------

@Composable
private fun FocusPopup(c: Controls) {
    val f = c.focusFilter
    Column {
        PopupTitle("Focus")
        PopupRow(Metas.of("focus").icon, "Do Not Disturb", f == NotificationManager.INTERRUPTION_FILTER_PRIORITY) {
            c.setFocus(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
        PopupRow(Icons.Rounded.Alarm, "Alarms Only", f == NotificationManager.INTERRUPTION_FILTER_ALARMS) {
            c.setFocus(NotificationManager.INTERRUPTION_FILTER_ALARMS)
        }
        PopupRow(Icons.Rounded.VolumeUp, "Total Silence", f == NotificationManager.INTERRUPTION_FILTER_NONE) {
            c.setFocus(NotificationManager.INTERRUPTION_FILTER_NONE)
        }
        PopupRow(Icons.Rounded.Check, "Off", f == NotificationManager.INTERRUPTION_FILTER_ALL) {
            c.setFocus(NotificationManager.INTERRUPTION_FILTER_ALL)
        }
    }
}

// ---------- Quick actions menu for utility tiles ----------

data class QA(val label: String, val icon: ImageVector, val run: () -> Unit)

private fun quickActions(id: String, c: Controls): List<QA> = when (id) {
    "camera" -> listOf(
        QA("Photo", Icons.Rounded.CameraAlt) { c.launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) },
        QA("Video", Icons.Rounded.Videocam) { c.launch(Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA)) },
    )
    "timer", "alarm" -> listOf(
        QA("Alarm", Icons.Rounded.Alarm) { c.launch(Intent(AlarmClock.ACTION_SHOW_ALARMS)) },
        QA("Timer", Icons.Rounded.Timer) { c.launch(Intent(AlarmClock.ACTION_SHOW_TIMERS)) },
    )
    "silent" -> listOf(
        QA("Ring", Metas.of("silent").icon) { c.setRinger(AudioManager.RINGER_MODE_NORMAL) },
        QA("Vibrate", Metas.of("silent").icon) { c.setRinger(AudioManager.RINGER_MODE_VIBRATE) },
    )
    "rotation" -> listOf(
        QA(if (c.on["rotation"] == true) "Auto-rotate on karo" else "Rotation lock karo", Metas.of("rotation").icon) {
            c.tap("rotation")
        },
    )
    "volume" -> listOf(
        QA("Volume panel", Icons.Rounded.VolumeUp) { c.launch(Intent(Settings.Panel.ACTION_VOLUME)) },
    )
    else -> listOf(QA("Kholo", Metas.of(id).icon) { c.tap(id) })
}

@Composable
private fun QuickMenu(id: String, c: Controls) {
    Column {
        PopupTitle(Tiles.byId[id]?.title ?: id)
        quickActions(id, c).forEach { qa -> PopupRow(qa.icon, qa.label, false) { qa.run() } }
    }
}
