package com.glasscc

import android.view.KeyEvent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AirplanemodeActive
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.BatterySaver
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BrightnessAuto
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.ScreenLockRotation
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Tile metadata ----------

data class Meta(val icon: ImageVector, val color: Color, val label: String)

object Metas {
    private val blue = Color(0xFF0A84FF)
    private val green = Color(0xFF30D158)
    private val orange = Color(0xFFFF9F0A)
    private val red = Color(0xFFFF453A)
    private val purple = Color(0xFF5E5CE6)
    private val yellow = Color(0xFFFFD60A)

    private val map: Map<String, Meta> by lazy {
        mapOf(
            "connectivity" to Meta(Icons.Rounded.Wifi, blue, "Connectivity"),
            "nowplaying" to Meta(Icons.Rounded.MusicNote, Color.White, "Now Playing"),
            "wifi" to Meta(Icons.Rounded.Wifi, blue, "Wi-Fi"),
            "cellular" to Meta(Icons.Rounded.SignalCellularAlt, green, "Mobile Data"),
            "bluetooth" to Meta(Icons.Rounded.Bluetooth, blue, "Bluetooth"),
            "airplane" to Meta(Icons.Rounded.AirplanemodeActive, orange, "Airplane"),
            "hotspot" to Meta(Icons.Rounded.WifiTethering, green, "Hotspot"),
            "vpn" to Meta(Icons.Rounded.VpnKey, blue, "VPN"),
            "nearby" to Meta(Icons.Rounded.Share, blue, "Nearby Share"),
            "rotation" to Meta(Icons.Rounded.ScreenLockRotation, red, "Orientation"),
            "silent" to Meta(Icons.Rounded.NotificationsOff, red, "Silent"),
            "focus" to Meta(Icons.Rounded.Bedtime, purple, "Focus"),
            "brightness" to Meta(Icons.Rounded.WbSunny, Color.White, "Brightness"),
            "volume" to Meta(Icons.Rounded.VolumeUp, Color.White, "Volume"),
            "torch" to Meta(Icons.Rounded.FlashlightOn, Color.White, "Flashlight"),
            "timer" to Meta(Icons.Rounded.Timer, Color.White, "Timer"),
            "alarm" to Meta(Icons.Rounded.Alarm, Color.White, "Alarm"),
            "calculator" to Meta(Icons.Rounded.Calculate, Color.White, "Calculator"),
            "camera" to Meta(Icons.Rounded.CameraAlt, Color.White, "Camera"),
            "lowpower" to Meta(Icons.Rounded.BatterySaver, yellow, "Low Power"),
            "darkmode" to Meta(Icons.Rounded.DarkMode, Color.White, "Dark Mode"),
            "cast" to Meta(Icons.Rounded.Cast, blue, "Mirroring"),
            "autobright" to Meta(Icons.Rounded.BrightnessAuto, Color.White, "Auto-Brightness"),
        )
    }

    fun of(id: String): Meta = map[id] ?: Meta(Icons.Rounded.MusicNote, Color.White, id)
}

// ---------- Tiles ----------

@Composable
fun ToggleTile(m: Meta, size: TileSize, active: Boolean, sub: String, onClick: () -> Unit, onLong: () -> Unit) {
    val bg by animateColorAsState(
        if (active) m.color else Color.Transparent,
        spring(stiffness = 500f),
        label = "bg",
    )
    val fg = if (active && m.color.luminance() > 0.7f) Color(0xFF111111) else Color.White
    val shape: Shape = if (size == TileSize.S) CircleShape else RoundedCornerShape(28.dp)
    GlassSurface(Modifier.fillMaxSize().pressScale(onClick, onLong), shape) {
        Box(Modifier.fillMaxSize().background(bg))
        when (size) {
            TileSize.WIDE -> Row(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                GIcon(m.icon, fg, 26.dp)
                Column {
                    GText(m.label, 14.sp, fg)
                    if (sub.isNotEmpty()) GText(sub, 11.sp, fg.copy(0.7f))
                }
            }
            TileSize.BIG -> Column(
                Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                GIcon(m.icon, fg, 40.dp)
                Column {
                    GText(m.label, 16.sp, fg)
                    if (sub.isNotEmpty()) GText(sub, 12.sp, fg.copy(0.7f))
                }
            }
            else -> GIcon(m.icon, fg, 28.dp, Modifier.align(Alignment.Center))
        }
    }
}

/** Vertical capsule slider: neeche se safed fill, hadd ke bahar kheenchne par rubber-band stretch. */
@Composable
fun SliderTile(value: Float, icon: ImageVector, onLong: () -> Unit, onChange: (Float) -> Unit) {
    val haptic = rememberHaptics()
    val v by animateFloatAsState(value, spring(stiffness = Spring.StiffnessHigh), label = "slider")
    var stretch by remember { mutableFloatStateOf(0f) }
    var atLimit by remember { mutableStateOf(false) }
    val sy by animateFloatAsState(1f + 0.06f * stretch, spring(dampingRatio = 0.5f, stiffness = 300f), label = "sy")
    val sx by animateFloatAsState(1f - 0.04f * stretch, spring(dampingRatio = 0.5f, stiffness = 300f), label = "sx")
    GlassSurface(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                scaleX = sx
                scaleY = sy
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = {
                        haptic(H.LONG)
                        onLong()
                    },
                    onTap = { onChange((1f - it.y / size.height).coerceIn(0f, 1f)) },
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { onChange((1f - it.y / size.height).coerceIn(0f, 1f)) },
                    onDragEnd = {
                        stretch = 0f
                        atLimit = false
                    },
                    onDragCancel = {
                        stretch = 0f
                        atLimit = false
                    },
                ) { change, _ ->
                    change.consume()
                    val raw = 1f - change.position.y / size.height
                    onChange(raw.coerceIn(0f, 1f))
                    val over = raw > 1f || raw < 0f
                    if (over && !atLimit) haptic(H.TICK)
                    atLimit = over
                    stretch = if (over) 1f else 0f
                }
            },
        RoundedCornerShape(26.dp),
    ) {
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(v.coerceIn(0f, 1f))
                .background(Color.White),
        )
        GIcon(
            icon,
            if (v > 0.14f) Color(0xFF111111) else Color.White,
            26.dp,
            Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
        )
    }
}

/** Gol button (connectivity cluster, popups). */
@Composable
fun Orb(id: String, c: Controls, size: androidx.compose.ui.unit.Dp, onClick: () -> Unit, onLong: () -> Unit) {
    val m = Metas.of(id)
    val active = c.on[id] == true
    val bg by animateColorAsState(
        if (active) m.color else Color.White.copy(0.2f),
        spring(stiffness = 500f),
        label = "orb",
    )
    Box(
        Modifier
            .pressScale(onClick, onLong)
            .size(size)
            .clip(CircleShape)
            .background(bg),
        contentAlignment = Alignment.Center,
    ) {
        GIcon(m.icon, Color.White, size * 0.46f)
    }
}

@Composable
private fun ClusterCircle(id: String, c: Controls, onLong: (String) -> Unit) {
    val m = Metas.of(id)
    val active = c.on[id] == true
    val bg by animateColorAsState(
        if (active) m.color else Color.White.copy(0.2f),
        spring(stiffness = 500f),
        label = "cluster",
    )
    Box(
        Modifier
            .pressScale({ c.tap(id) }, { onLong(id) })
            .fillMaxHeight()
            .aspectRatio(1f, matchHeightConstraintsFirst = true)
            .clip(CircleShape)
            .background(bg),
        contentAlignment = Alignment.Center,
    ) {
        GIcon(m.icon, Color.White, 26.dp)
    }
}

@Composable
private fun MiniCluster(c: Controls, onLong: (String) -> Unit) {
    Box(Modifier.fillMaxHeight().aspectRatio(1f, matchHeightConstraintsFirst = true)) {
        MiniDot("bluetooth", c, onLong, Modifier.align(Alignment.TopStart))
        MiniDot("hotspot", c, onLong, Modifier.align(Alignment.TopEnd))
        MiniDot("nearby", c, onLong, Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun MiniDot(id: String, c: Controls, onLong: (String) -> Unit, modifier: Modifier) {
    val m = Metas.of(id)
    val active = c.on[id] == true
    Box(
        modifier
            .pressScale({ c.tap(id) }, { onLong(id) })
            .size(26.dp)
            .clip(CircleShape)
            .background(if (active) m.color else Color.White.copy(0.2f)),
        contentAlignment = Alignment.Center,
    ) {
        GIcon(m.icon, Color.White, 14.dp)
    }
}

/** 2x2: Airplane, Cellular, Wi-Fi aur Bluetooth/Hotspot/Nearby ka mini cluster. */
@Composable
fun ConnectivityTile(c: Controls, onLong: (String) -> Unit) {
    GlassSurface(Modifier.fillMaxSize(), RoundedCornerShape(28.dp)) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ClusterCircle("airplane", c, onLong)
                ClusterCircle("cellular", c, onLong)
            }
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ClusterCircle("wifi", c, onLong)
                MiniCluster(c, onLong)
            }
        }
    }
}

@Composable
private fun MediaBtn(icon: ImageVector, size: androidx.compose.ui.unit.Dp, code: Int, c: Controls) {
    Box(Modifier.pressScale({ c.mediaKey(code) }).padding(6.dp)) {
        GIcon(icon, Color.White, size)
    }
}

@Composable
fun NowPlayingTile(c: Controls, size: TileSize, onLong: () -> Unit) {
    GlassSurface(Modifier.fillMaxSize().pressScale({}, onLong), RoundedCornerShape(28.dp)) {
        if (size == TileSize.WIDE) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                GIcon(Icons.Rounded.MusicNote, Color.White.copy(0.8f), 22.dp)
                GText("Not Playing", 14.sp, Color.White.copy(0.8f), Modifier.weight(1f))
                MediaBtn(Icons.Rounded.SkipPrevious, 24.dp, KeyEvent.KEYCODE_MEDIA_PREVIOUS, c)
                MediaBtn(Icons.Rounded.PlayArrow, 28.dp, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, c)
                MediaBtn(Icons.Rounded.SkipNext, 24.dp, KeyEvent.KEYCODE_MEDIA_NEXT, c)
            }
        } else {
            Column(
                Modifier.fillMaxSize().padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    GIcon(Icons.Rounded.MusicNote, Color.White.copy(0.8f), 22.dp)
                    GText("Not Playing", 14.sp, Color.White.copy(0.8f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    MediaBtn(Icons.Rounded.SkipPrevious, 30.dp, KeyEvent.KEYCODE_MEDIA_PREVIOUS, c)
                    MediaBtn(Icons.Rounded.PlayArrow, 34.dp, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, c)
                    MediaBtn(Icons.Rounded.SkipNext, 30.dp, KeyEvent.KEYCODE_MEDIA_NEXT, c)
                }
            }
        }
    }
}

/** onLongTile(popupId): popup kholne ke liye. */
@Composable
fun TileContent(p: Placed, c: Controls, onLongTile: (String) -> Unit) {
    val haptic = rememberHaptics()
    val long: (String) -> Unit = { id ->
        haptic(H.LONG)
        onLongTile(id)
    }
    when (p.id) {
        "connectivity" -> ConnectivityTile(c) { id -> long(if (id == "wifi") "wifi" else "connectivity") }
        "nowplaying" -> NowPlayingTile(c, p.size) { long("nowplaying") }
        "brightness" -> SliderTile(c.brightness, Icons.Rounded.WbSunny, { onLongTile("brightness") }) { c.setBrightness(it) }
        "volume" -> SliderTile(c.volume, Icons.Rounded.VolumeUp, { onLongTile("volume") }) { c.setVolume(it) }
        else -> ToggleTile(
            Metas.of(p.id),
            p.size,
            c.on[p.id] == true,
            c.sub(p.id),
            { c.tap(p.id) },
            { long(p.id) },
        )
    }
}
