# Glass Control Center (Phase 1 v2)

iPhone jaisa Control Center, Android 10+ ke liye (Android 12+ par asli blur). Screen ke upar-right kone se neeche swipe karo.

## Is version mein
- 3 vertical pages (Favorites, Media, Connectivity) + right-edge dots (tap ya dots par drag)
- 4-column grid, sizes 1x1 (gol), 2x1, 1x2 (sliders), 2x2 (Connectivity, Now Playing)
- Edit mode (long-press ya "+"): jiggle, "-" se hatao, drag se reorder, resize handle drag se size badlo, "+" se searchable Add sheet
- Bounce: press par 0.93 spring, drag/resize par rubber-band stretch, chhorne par overshoot + haptic tick
- Sliders: brightness / volume, hadd se bahar kheenchne par stretch
- Long-tap popups: Wi-Fi networks list (signal, lock, Connected), Connectivity, Brightness (Dark Mode, Auto-Brightness), Flashlight (Low/Medium/High/Max, Android 13+ aur phone support par), Media, Focus, aur Camera/Timer/Silent quick menu
- Glass clarity slider (Clear <-> Tinted): app ki main screen par aur edit mode mein
- Power button (Accessibility service on karo), battery %
- Permission missing ho to glass prompt

## Hadein
- Wi-Fi, Bluetooth, Airplane, Mobile data, Hotspot, VPN, Low Power seedha on/off nahi hote; tap par system panel/settings khulti hai
- Wi-Fi network par tap system Wi-Fi panel kholta hai (Android password dialog khud dikhata hai)
- Now Playing: play/pause/next kaam karte hain, lekin track ka naam aur artwork Phase 3 mein (notification access chahiye)
- Notification center Phase 2 mein

## APK banana
1. GitHub: folder ko repo mein upload karo, Actions -> "Build APK" -> Run workflow, artifact mein app-debug.apk
2. Android Studio: folder kholo, Run

## Pehli baar
Permissions app ki main screen par do (Overlay zaroori), phir Start. Infinix par Battery -> Unrestricted aur Autostart on karo.
